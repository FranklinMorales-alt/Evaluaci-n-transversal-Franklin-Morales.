# ==========================
# Diccionarios iniciales
# ==========================

productos = {

    'M001': ['Alimento Premium', 'comida', 'DogPlus', 10, True, False],
    'M002': ['Arena Aglomerante', 'higiene', 'CatClean', 8, False, False],
    'M003': ['Snack Dental', 'snack', 'BiteJoy', 1, True, True],
    'M004': ['Shampoo Suave', 'higiene', 'PetCare', 0.5, False, True],
    'M005': ['Correa Nylon', 'accesorio', 'WalkPro', 0.3, True, False],
    'M006': ['Cama Mediana', 'accesorio', 'CozyPet', 2, False, False]

}

stock = {

    'M001': [32990, 12],
    'M002': [9990, 0],
    'M003': [5490, 25],
    'M004': [7990, 5],
    'M005': [11990, 7],
    'M006': [24990, 3]

}


# ==========================
# Funciones
# ==========================

def unidades_categoria(categoria):
    total = 0
    for codigo in productos:
        if productos[codigo][1].lower() == categoria.lower():
            total += stock[codigo][1]
    print("El total de unidades disponibles es:", total)


def busqueda_precio(precio_min, precio_max):
    lista = []

    for codigo in stock:
        precio = stock[codigo][0]
        unidades = stock[codigo][1]

        if precio_min <= precio <= precio_max and unidades > 0:
            nombre = productos[codigo][0]
            lista.append(nombre + "--" + codigo)

    lista.sort()

    if len(lista) == 0:
        print("No hay productos en ese rango de precios.")
    else:
        print("Los productos encontrados son:", lista)


def actualizar_precio(codigo, nuevo_precio):
    codigo = codigo.upper()

    if codigo in stock:
        stock[codigo][0] = nuevo_precio
        return True
    return False


def agregar_producto(codigo, nombre, categoria, marca, peso_kg,
                     es_importado, es_para_cachorro, precio, unidades):

    codigo = codigo.upper()

    if codigo in productos:
        return False

    productos[codigo] = [
        nombre,
        categoria,
        marca,
        peso_kg,
        es_importado,
        es_para_cachorro
    ]

    stock[codigo] = [precio, unidades]

    return True


def eliminar_producto(codigo):

    codigo = codigo.upper()

    if codigo in productos:
    
        del productos[codigo]
        del stock[codigo]
        return True

    return False


# ==========================
# Funciones de validación
# ==========================

def validar_codigo(codigo):

    if codigo.strip() == "":
        return False

    if codigo.upper() in productos:
        return False
    return True


def validar_nombre(nombre):
    return nombre.strip() != ""


def validar_categoria(categoria):
    return categoria.strip() != ""


def validar_marca(marca):
    return marca.strip() != ""


def validar_peso(peso):
    return peso > 0


def validar_importado(valor):
    return valor.lower() in ("s", "n")


def validar_cachorro(valor):
    return valor.lower() in ("s", "n")


def validar_precio(precio):
    return precio > 0


def validar_unidades(unidades):
    return unidades >= 0


# ==========================
# Programa principal
# ==========================

while True:

    print("\n========== MENÚ PRINCIPAL ==========")
    print("1. Unidades por categoría")
    print("2. Búsqueda de productos por rango de precio")
    print("3. Actualizar precio de producto")
    print("4. Agregar producto")
    print("5. Eliminar producto")
    print("6. Salir")
    print("=====================================")

    opcion = input("Ingrese opción: ")

    if opcion == "1":

        categoria = input("Ingrese categoría a consultar: ")
        unidades_categoria(categoria)

    elif opcion == "2":

        while True:
            try:
                precio_min = int(input("Ingrese precio mínimo: "))
                precio_max = int(input("Ingrese precio máximo: "))

                if precio_min >= 0 and p_max >= 0 and p_min <= p_max:
                    break
            except:
                print("Debe ingresar valores enteros")

        busqueda_precio(precio_min, precio_max)

    elif opcion == "3":

        while True:
            codigo = input("Ingrese código del producto: ")

            try:
                nuevo_precio = int(input("Ingrese nuevo precio: "))

                if nuevo_precio <= 0:
                    print("Precio inválido")
                    continue

            except:
                print("Debe ingresar un precio entero")
                continue

            if actualizar_precio(codigo, nuevo_precio):
                print("Precio actualizado")
            else:
                print("El código no existe")

            seguir = input("¿Desea actualizar otro precio (s/n)?: ").lower()

            if seguir == "n":
                break

    elif opcion == "4":

        codigo = input("Ingrese código del producto: ")

        if not validar_codigo(codigo):
            print("Código inválido o ya existe")
            continue

        nombre = input("Ingrese nombre: ")
        if not validar_nombre(nombre):
            print("Nombre inválido")
            continue

        categoria = input("Ingrese categoría: ")
        if not validar_categoria(categoria):
            print("Categoría inválida")
            continue

        marca = input("Ingrese marca: ")
        if not validar_marca(marca):
            print("Marca inválida")
            continue

        try:
            peso = float(input("Ingrese peso (kg): "))
        except:
            print("Peso inválido")
            continue

        if not validar_peso(peso):
            print("Peso inválido")
            continue

        importado = input("¿Es importado? (s/n): ")

        if not validar_importado(importado):
            print("Valor inválido")
            continue

        cachorro = input("¿Es para cachorro? (s/n): ")

        if not validar_cachorro(cachorro):
            print("Valor inválido")
            continue

        try:
            precio = int(input("Ingrese precio: "))
        except:
            print("Precio inválido")
            continue

        if not validar_precio(precio):
            print("Precio inválido")
            continue

        try:
            unidades = int(input("Ingrese unidades: "))
        except:
            print("Unidades inválidas")
            continue

        if not validar_unidades(unidades):
            print("Unidades inválidas")
            continue

        es_importado = importado.lower() == "s"
        es_para_cachorro = cachorro.lower() == "s"

        if agregar_producto(
                codigo,
                nombre,
                categoria,
                marca,
                peso,
                es_importado,
                es_para_cachorro,
                precio,
                unidades):

            print("Producto agregado")
        else:
            print("El código ya existe")

    elif opcion == "5":

        codigo = input("Ingrese código del producto: ")

        if eliminar_producto(codigo):
            print("Producto eliminado")
        else:
            print("El código no existe")

    elif opcion == "6":

        print("Programa finalizado.")
        break

    else:
        print("Debe seleccionar una opción válida")